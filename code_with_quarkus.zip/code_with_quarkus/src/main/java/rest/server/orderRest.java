package rest.server;

import java.util.List;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import jakarta.inject.Inject;
import jakarta.persistence.criteria.Order;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;



@Path("/api/country/")
public class orderRest {

	@Inject
	@RestClient
	private orderRest OrderRest;
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getOrders")
	public Response getAllOrders() {
		List<Order> order =  orderRest.getAll();
		return Response.ok().entity(order).build();
	}


	private static List<Order> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
}