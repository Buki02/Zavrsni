package scheduler;



import java.util.List;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import io.quarkus.scheduler.Scheduled;
import jakarta.inject.Inject;

import models.Order;
import rest.client.orderClient;
import service.orderService;

public class orderScheduler {

	@Inject
	@RestClient
	private orderClient orderClient;
	
	@Inject
	private orderService orderService;
	
	@Scheduled(every="10s")
	public void getAllOrders() {
		List<Order> order = orderClient.getAll();
		orderService.saveOrders(order);
		
	}
}

