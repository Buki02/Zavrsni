package service;



import java.util.List;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

import models.Order;

@Dependent
public class orderService {
	
	@Inject
	private EntityManager em;

	@Transactional
	public void saveOrders(List<Order> orders) {
		
		List<Order> savedOrders = getAllOrders();
		
		orders.removeAll(savedOrders);
		
		for (Order order : orders) {
			em.merge(order);
		}
	}
	
	@Transactional
	public List<Order> getAllOrders(){
		return em.createNamedQuery(Order.GET_ALL, Order.class).getResultList();
	}

	

	

	
}

